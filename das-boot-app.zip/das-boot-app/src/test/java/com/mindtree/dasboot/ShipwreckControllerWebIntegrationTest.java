package com.mindtree.dasboot;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
@SpringBootTest
public class ShipwreckControllerWebIntegrationTest {
//not clear
}
