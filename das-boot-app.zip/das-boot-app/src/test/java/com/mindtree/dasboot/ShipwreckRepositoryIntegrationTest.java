package com.mindtree.dasboot;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import com.mindtree.dasboot.model.Shipwreck;
import com.mindtree.dasboot.repository.ShipWreckRepository;
import com.mindtree.dasboot.service.ShipWreckService;
@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
@SpringBootTest
public class ShipwreckRepositoryIntegrationTest {
	@Autowired
	ShipWreckRepository shipWreckRepo;
@Test
public void testFindAll()
{
  List<Shipwreck> wrecks=shipWreckRepo.findAll();
  assertThat(wrecks.size(),is(greaterThanOrEqualTo(0)));

}

}
