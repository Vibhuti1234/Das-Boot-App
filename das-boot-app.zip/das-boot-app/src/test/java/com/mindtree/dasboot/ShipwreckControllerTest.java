package com.mindtree.dasboot;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.*;
import com.mindtree.dasboot.controller.ShipwreckController;
import com.mindtree.dasboot.exception.NoShipFoundException;
import com.mindtree.dasboot.model.Shipwreck;
import com.mindtree.dasboot.service.ShipWreckService;

public class ShipwreckControllerTest {
@InjectMocks
private ShipwreckController sc;
@Mock
private ShipWreckService shipWreckService;
@Before
public void init()
{
	MockitoAnnotations.initMocks(this);

}
@Test
public void testShipwreckGet() throws NoShipFoundException
{ Shipwreck sw=new Shipwreck();
sw.setId(2L);
when(shipWreckService.get(2L)).thenReturn(sw);
Shipwreck wreck=sc.get(2L);
assertEquals(2L,wreck.getId().longValue());

	
}

}
