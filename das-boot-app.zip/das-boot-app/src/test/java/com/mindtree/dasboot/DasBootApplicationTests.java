package com.mindtree.dasboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DasBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
