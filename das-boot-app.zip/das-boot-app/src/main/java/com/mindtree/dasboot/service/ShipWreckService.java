package com.mindtree.dasboot.service;

import java.util.List;

import com.mindtree.dasboot.exception.NoShipFoundException;
import com.mindtree.dasboot.model.Shipwreck;

public interface ShipWreckService {
	public abstract List<Shipwreck> list();

	public abstract Shipwreck create(Shipwreck shipWreck);

	public abstract Shipwreck get(Long id) throws NoShipFoundException;

	public abstract Shipwreck update(Long id, Shipwreck shipWreck);

	public abstract Shipwreck delete(Long id);

}
