package com.mindtree.dasboot.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dasboot.exception.NoShipFoundException;
import com.mindtree.dasboot.model.Shipwreck;
import com.mindtree.dasboot.repository.ShipWreckRepository;
import com.mindtree.dasboot.service.ShipWreckService;
@Service
public class ShipWreckServiceImpl implements ShipWreckService{

	@Autowired
	private ShipWreckRepository repository;
	@Override
	public List<Shipwreck> list() {
		return repository.findAll();
		}

	@Override
	public Shipwreck create(Shipwreck shipWreck) {
		return repository.saveAndFlush(shipWreck);
		}

	@Override
	public Shipwreck get(Long id) throws NoShipFoundException {
		return repository.findAll().stream().filter(i->i.getId()==id).findAny().orElseThrow(()->new NoShipFoundException("Not found"));
		}

	@Override
	public Shipwreck update(Long id, Shipwreck shipWreck) {
		//Shipwreck existingShipWreck = repository.getOne(id);
		 Shipwreck save = repository.save(shipWreck);
		 return save;
	}

	@Override
	public Shipwreck delete(Long id) {
		repository.deleteById(id);
		return null;
	}

	public void setShipWreckRepository(ShipWreckRepository shipWreckRepository) {
		this.repository = shipWreckRepository;
		
	}


}
