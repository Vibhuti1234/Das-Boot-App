package com.mindtree.dasboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.dasboot.model.Shipwreck;
@Repository
public interface ShipWreckRepository extends JpaRepository<Shipwreck, Long> {

	//Shipwreck findOne(Long id);

}
